const { querySql, queryOne } = require('../utils/mysql-dbHelper');
require('jsonwebtoken');
require('multer');
const boom = require('boom');
const { validationResult } = require('express-validator');
const {
    CODE_ERROR,
    CODE_SUCCESS
} = require('../utils/config');
const { decode } = require('../utils/user-jwt');

async function createOnlineResume(req, res) {
    const err = validationResult(req);
    if (!err.isEmpty()) {
        const [{ msg }] = err.errors;
        throw boom.badRequest(msg);
    } else {
        let { education, campus_experience, intern_experience, project_experience, training_experience, receive_honor, related_works, skills_and_specialties, self_introduction, area, expected_salary } = req.body;
        if (!education || !campus_experience || !intern_experience || !project_experience || !training_experience || !receive_honor || !related_works || !skills_and_specialties || !self_introduction) {
            //  || !area || !expected_salary
            res.json({
                code: CODE_ERROR,
                msg: '参数不完整',
                data: null
            })
        }
        console.info('req.body', req.body)
        const decodedToken = decode(req);
        const { username } = decodedToken;
        const sql = `select * from online_resumes where username='${username}'`;
        let result;
        try {
            result = await queryOne(sql);
        } catch (e) {
            res.json({
            code: CODE_ERROR,
            msg: '查询失败',
            data: null
            })
            console.error(e)
        }
        if (result) {
            res.json({
                code: CODE_ERROR,
                msg: '您已经提交过了',
                data: {
                    username: result.username
                }
            })
        } else {
            const addSql = `insert into online_resumes (username, education, campus_experience, intern_experience, project_experience, training_experience, receive_honor, related_works, skills_and_specialties, self_introduction, area, expected_salary) values('${username}', '${education}', '${campus_experience}', '${intern_experience}', '${project_experience}', '${training_experience}', '${receive_honor}', '${related_works}', '${skills_and_specialties}', '${self_introduction}', '${area}', '${expected_salary}')`;
            try {
                await querySql(addSql);
                res.json({
                    code: CODE_SUCCESS,
                    msg: '提交成功',
                    data: null
                })
            } catch (e) {
                res.json({
                    code: CODE_ERROR,
                    msg: '提交失败',
                    data: null
                })
                console.error(e);
            }
        }

    }
}

module.exports = {
    createOnlineResume
}
