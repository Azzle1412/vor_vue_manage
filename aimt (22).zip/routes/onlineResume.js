const express = require('express');
const router = express.Router();
const service = require('../services/onlineResumeService');
const multer = require('multer');


// 创建在线简历接口
router.post('/createOnlineResume', service.createOnlineResume);

module.exports = router;
