const neo4j = {
    host: 'localhost',
    port: '7687',
    user: 'neo4j',
    password: '123456'
}

module.exports = neo4j;
