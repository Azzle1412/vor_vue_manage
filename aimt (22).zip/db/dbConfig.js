const mysql = {
    host: 'localhost',
    port: '3305',
    user: 'root',
    password: '123456', // 密码
    database: 'mutation_test_web', // 数据库
    // employment_recommendations_system
    // mutation_test_web
    connectTimeout: 5000 // 连接超时
}

module.exports = mysql;
